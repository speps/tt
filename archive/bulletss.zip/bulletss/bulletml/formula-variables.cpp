#include "formula-variables.h"

namespace Variables {
	double rank;
	std::vector<double>* parameters;
	BulletMLRunner* runner;
}
