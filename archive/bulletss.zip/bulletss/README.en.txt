barrage 360 deg. ver 0.0.1

it's not game, but viewer.

download "shiroi danmakukun"
http://user.ecc.u-tokyo.ac.jp/~s31552/wp/sdmkun/

copy bulletss.exe, cpu.dll, bulletml.dll into sdmkun
directory(folder). then execute bulletss.exe.

------------------
 shinichiro.h
  s31552@mail.ecc.u-tokyo.ac.jp
  http://user.ecc.u-tokyo.ac.jp/~s31552/wp/

