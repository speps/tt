#ifndef BOHA_CPU
#define BOHA_CPU

#include "util.h"
#include "cpuinfo.h"

#include <memory>
#include <string>

class CpuInputBase {
protected:
	typedef std::pair<Point, Point> PosSpd;
    typedef std::vector<PosSpd> PosSpds;

public:
    CpuInputBase() : lastTurn_(-1), axis_(0) {}

	virtual ~CpuInputBase() {}

    virtual int getAxis() {
		update();
		return axis_;
    }
    virtual bool getButton(int id) {
		update();
		return decision_ && id == 1;
	}

	static CpuInputBase* getDefaultCpu();
	static void setCpuInfomation(CpuInfo* info) {
		info_ = info;
	}

public:
	virtual void registShot(float, float, float, float) {}

	virtual int getAxisEvaluation(int axis) {
		return evaluations_[axis];
	}

	virtual int getConfidence() const { return 100; }

	virtual void report() const {}

public:
    void update();

public:
	const std::string& name() const { return name_; }

protected:
	void message(const std::string& msg);

private:
	virtual void calc() =0;

protected:
	void initEvaluation();

protected:
    int lastTurn_;
    int prevIndex_;

protected:
    int axis_;
    bool decision_;

	int evaluations_[9];

	std::string name_;

protected:
	static CpuInfo* info_;

protected:
	// utility

	Point getMovedPoint(const Point& pnt, int axis);

	double getShotAngle(const PosSpd& shot);

	const std::string& getAxisString(int axis);
	const Point& getAxisVector(int axis);

	static const Point axis2vec[9];

protected:
	enum { NONE, UP, UPRIGHT, RIGHT, DOWNRIGHT, DOWN, DOWNLEFT, LEFT, UPLEFT };

	bool axisIsUp(int a) const {
		return a == UP || a == UPRIGHT || a == UPLEFT;
	}
	bool axisIsDown(int a) const {
		return a == DOWN || a == DOWNRIGHT || a == DOWNLEFT;
	}
	bool axisIsRight(int a) const {
		return a == RIGHT || a == UPRIGHT || a == DOWNRIGHT;
	}
	bool axisIsLeft(int a) const {
		return a == LEFT || a == UPLEFT || a == DOWNLEFT;
	}

};

#endif // ! BOHA_CPU
