/**
 * $Id: oblivion.cc,v 1.2 2003/09/16 08:25:57 i Exp $
 *
 * Copyright (C) shinichiro.h <s31552@mail.ecc.u-tokyo.ac.jp>
 *  http://user.ecc.u-tokyo.ac.jp/~s31552/wp/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include "oblivion.h"

#include "cpuutil.h"

//#include <functional>
//#include <algorithm>

//#include <boost/functional.hpp>

const size_t OblivionCpu::WAIT_SAMPLES = 50;
const int OblivionCpu::WAIT_FRAMES = 10;
const int OblivionCpu::OVER_MOVE = 20;
const double OblivionCpu::WAIT_RATE = 2.0 / 3;
const double OblivionCpu::LIMIT_BULLET_ANGLE = dtor(5);
const int OblivionCpu::NEAR_WALL = 15;
const size_t OblivionCpu::HANDLABLE_NUM = 100;
const int OblivionCpu::MAX_CONFIDENCE = 50;

OblivionCpu::OblivionCpu()
	: movingAxis_(0), isMoving_(false), firstFrame_(-1),
	  dangerFrame_(-1), prevAxis_(0)
{
	decision_ = false;

	name_ = "oblivion";
}

bool OblivionCpu::isAxisOK(int axis) const {
	if (prevAxis_ == 0) return true;

	int opposite = (axis) ? ((axis+3)&7)+1 : 0;
	if (prevAxis_ == opposite ||
		prevAxis_ == (opposite&7)+1 ||          // �E��]
		prevAxis_ == ((opposite-2)&7)+1)         // ����]
	{
		return false;
	}

	return true;
}

void OblivionCpu::decideAxis() {
	const Point& pnt = info_->getPlayerPnt();

	const Point& upper = info_->getPlayerMaxPnt();

	// �T���v���Ǝ��@�Ƃ̊p�x�̕��ς��Ƃ�
	Point averageVec(0, 0);
	for (size_t i = 0; i < samples_.size(); i++) {
		Point vec(pnt - samples_[i].first);
		averageVec += vec;
	}
	averageVec /= samples_.size();

	// �l���̂ǂꂪ�K�؂Ȋp�x�����l���āA
	// ���̌�L������I������B

	// ������180�x�ōl����Ηǂ�
	if (averageVec.y < 0) averageVec = -averageVec;

	double angle = averageVec.angle();
	if (angle > PI_PER_8 * 11 || angle < PI_PER_8 * 5) {
		if (dangerFrame_ > lastTurn_) {
			if (!isAxisOK(UP))
				movingAxis_ = DOWN;
			else if (!isAxisOK(DOWN))
				movingAxis_ = UP;
		}

		if (movingAxis_ == NONE) {
			movingAxis_ = (pnt.y > upper.y / 2)
				? UP : DOWN;
		}
	}
	else if (angle > PI_PER_8 * 9) {
		if (dangerFrame_ > lastTurn_) {
			if (!isAxisOK(UPLEFT))
				movingAxis_ = DOWNRIGHT;
			else if (!isAxisOK(DOWNRIGHT))
				movingAxis_ = UPLEFT;
		}

		if (movingAxis_ == NONE) {
			int len1 = (int)std::min(pnt.x, pnt.y);
			int len2 = (int)std::min(upper.x-pnt.x,upper.y-pnt.y);
			movingAxis_ =
				(len1 > len2) ? UPLEFT : DOWNRIGHT;
		}
	}
	else if (angle > PI_PER_8 * 7) {
		if (dangerFrame_ > lastTurn_) {
			if (!isAxisOK(RIGHT))
				movingAxis_ = LEFT;
			else if (!isAxisOK(LEFT))
				movingAxis_ = RIGHT;
		}

		if (movingAxis_ == NONE) {
			movingAxis_ = (pnt.x > upper.x / 2)
				? LEFT : RIGHT;
		}
	}
	else {
		if (dangerFrame_ > lastTurn_) {
			if (!isAxisOK(UPRIGHT))
				movingAxis_ = DOWNLEFT;
			else if (!isAxisOK(DOWNLEFT))
				movingAxis_ = UPRIGHT;
		}

		if (movingAxis_ == NONE) {
			int len1 = (int)std::min(pnt.x, upper.y-pnt.y);
			int len2 = (int)std::min(upper.x-pnt.x, pnt.y);
			movingAxis_ =
				(len1 > len2) ? DOWNLEFT : UPRIGHT;
		}
	}

	// �ǂɂԂ����Ă���ꍇ
	if (movingAxis_ == UPRIGHT) {
		if (pnt.y < NEAR_WALL) movingAxis_ = RIGHT;
		else if (pnt.x > upper.x-NEAR_WALL)
			movingAxis_ = UP;
	}
	else if (movingAxis_ == UPLEFT) {
		if (pnt.y < NEAR_WALL) movingAxis_ = LEFT;
		else if (pnt.x < NEAR_WALL)	movingAxis_ = UP;
	}
	else if (movingAxis_ == DOWNRIGHT) {
		if (pnt.y > upper.y-NEAR_WALL)
			movingAxis_ = RIGHT;
		else if (pnt.x > upper.x-NEAR_WALL)
			movingAxis_ = DOWN;
	}
	else if (movingAxis_ == DOWNLEFT) {
		if (pnt.y > upper.y-NEAR_WALL)
			movingAxis_ = LEFT;
		else if (pnt.x < NEAR_WALL)	movingAxis_ = DOWN;
	}
	else if ((movingAxis_ == UP && pnt.y < NEAR_WALL) ||
			 (movingAxis_ == DOWN &&
			  pnt.y > upper.y-NEAR_WALL))
	{
		movingAxis_ = (pnt.x > upper.x / 2)
			? LEFT : RIGHT;
	}
	else if ((movingAxis_ == LEFT && pnt.x < NEAR_WALL) ||
			 (movingAxis_ == RIGHT &&
			  pnt.x > upper.x-NEAR_WALL))
	{
		movingAxis_ = (pnt.y > upper.y / 2)
			? UP : DOWN;
	}

	prevAxis_ = movingAxis_;

/*
	if (getConfidence() > 5) {
		message(getAxisString(movingAxis_));
	}
*/

	// ���������܂����Ƃ���ňړ��v��ł�

	// �v��̏�����
	startMoveFrame_ = -1;
	endMoveFrame_ = -1;

	for (PosSpds::const_iterator ite = samples_.begin();
		 ite != samples_.end(); ++ite)
	{
		updateMovingPlan(*ite);
	}

	// ��n��
	samples_.clear();
	firstFrame_ = -1;

}

void OblivionCpu::updateMovingPlan(const PosSpd& pas) {
	int turn = (firstFrame_ == -1) ? lastTurn_ : firstFrame_;

	// ���̒e������Ȃ��ʒu�܂ł����ɂ�
	// �ǂꂾ���̎��Ԃłǂꂾ�������Ηǂ��̂��H

	// �܂���]�����č��W�n�����킹��
	Point vec(info_->getPlayerPnt() - pas.first);
	Point spd(pas.second);

	double rotAngle = - PI_PER_4 * (movingAxis_-1);
	vec.rotate(rotAngle);
	spd.rotate(rotAngle);

	// �ǂꂾ�����Ԃ�������́B
	double collSecond = vec.x / spd.x;

	// �ǂꂾ�������Ηǂ��́B(�����炩�]�T������)
	double safeLength = vec.y - spd.y * collSecond + OVER_MOVE;
	double safeSecond = safeLength / info_->getPlayerSpd();
	int safeFrame = static_cast<int>(safeSecond / info_->getSpf());

    // ���Ɍ����ꂽ�e��A������ʂ�e�͖����B
	// ���̔���͂����Ƒ������ׂ���������Ȃ��B
	if (collSecond < 0 || collSecond < safeSecond) return;

	// �ړ��J�n�����𑁂߂邩���B
	if (!isMoving_) {
		int newStartMoveFrame = turn
			+ static_cast<int>(
				(collSecond-safeSecond)*WAIT_RATE/info_->getSpf());
		if (startMoveFrame_ == -1 || startMoveFrame_ > newStartMoveFrame) {
			if (endMoveFrame_ != -1) {
				endMoveFrame_ += newStartMoveFrame - startMoveFrame_;
			}
			startMoveFrame_ = newStartMoveFrame;
		}
	}

	// �ړ��I��������x�߂邩���B
	if (!isMoving_) {
		int newEndMoveFrame = startMoveFrame_ + safeFrame;
		if (endMoveFrame_ == -1 || endMoveFrame_ < newEndMoveFrame) {
			endMoveFrame_ = newEndMoveFrame;
		}
	}
	else {
		int newEndMoveFrame = turn + safeFrame;
		if (endMoveFrame_ < newEndMoveFrame) {
			endMoveFrame_ = newEndMoveFrame;
		}
	}

	// �댯�I��������x�߂邩���B
	int collFrame =
		static_cast<int>(collSecond / info_->getSpf()) + lastTurn_;
	if (dangerFrame_ == -1 || dangerFrame_ < collFrame) {
		dangerFrame_ = collFrame;
	}

}

bool OblivionCpu::meetWall() const {
	const Point& pnt = info_->getPlayerPnt();
	const Point& upper = info_->getPlayerMaxPnt();

	return (
		(axisIsUp(movingAxis_) && pnt.y < NEAR_WALL) ||
		(axisIsDown(movingAxis_) && pnt.y > upper.y-NEAR_WALL) ||
		(axisIsRight(movingAxis_) && pnt.x > upper.x-NEAR_WALL) ||
		(axisIsLeft(movingAxis_) && pnt.x < NEAR_WALL)
		);
}

void OblivionCpu::calc() {
	if (isMoving_) {
		// �ړ��I�����ȁB
		if (lastTurn_ > endMoveFrame_ || meetWall()) {
			movingAxis_ = NONE;
			axis_ = NONE;

			// ���Z�b�g
			firstFrame_ = startMoveFrame_ =	endMoveFrame_ =	-1;
			isMoving_ = false;
		}
	}
	// �܂��ړ���₪��܂��Ă��Ȃ���
	else if (movingAxis_ == NONE) {
		// �T���v�����������W�܂邩�A���Ԃ��o�߂���ƈړ����������肷��
		if (firstFrame_ != -1 && firstFrame_ + WAIT_FRAMES < lastTurn_) {
			decideAxis();
		}
	}
	// �ړ��J�n
	else if (lastTurn_ >= startMoveFrame_ && startMoveFrame_ != -1) {
		axis_ = movingAxis_;
		isMoving_ = true;
	}

	if (axis_ != NONE) {
		evaluations_[axis_] = 30;
		evaluations_[(((axis_-2)&7)+1)] = 20;
		evaluations_[((axis_&7)+1)] = 20;
		evaluations_[(((axis_-3)&7)+1)] = 10;
		evaluations_[(((axis_+1)&7)+1)] = 10;
		evaluations_[0] = 10;
	}


}

int OblivionCpu::getConfidence() const {
	if (handlables_.empty()) return 0;

	int ok = 0;
	for (std::deque<bool>::const_iterator ite = handlables_.begin();
		 ite != handlables_.end(); ++ite)
	{
		if (*ite) ok++;
	}

	return ok * MAX_CONFIDENCE / handlables_.size();
}

void OblivionCpu::registShot(float x, float y, float sx, float sy) {
	PosSpd pas(Point(x, y), Point(sx, sy));

	if (handlables_.size() == HANDLABLE_NUM) {
		handlables_.pop_back();
	}

	double angle = getShotAngle(pas);
	if (angle > LIMIT_BULLET_ANGLE) {
		handlables_.push_front(false);
		return;
	}

	handlables_.push_front(true);

	// �܂��ړ���₪��܂��Ă��Ȃ���
	if (movingAxis_ == NONE) {
		if (firstFrame_ == -1) firstFrame_ = lastTurn_;

		// �T���v����o�^
		samples_.push_back(pas);

		// �T���v�����������W�܂邩�A���Ԃ��o�߂���ƈړ����������肷��
		if (samples_.size() == WAIT_SAMPLES) {
			decideAxis();
		}
	}
	else {
		updateMovingPlan(pas);
	}
}

