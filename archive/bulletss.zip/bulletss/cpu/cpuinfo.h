/**
 * $Id: cpuinfo.h,v 1.2 2003/09/16 08:25:57 i Exp $
 *
 * Copyright (C) shinichiro.h <s31552@mail.ecc.u-tokyo.ac.jp>
 *  http://user.ecc.u-tokyo.ac.jp/~s31552/wp/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef cpuinfo_h_
#define cpuinfo_h_

#include "util.h"

#include <utility>
#include <vector>

/// cpu �ɂ���Ă��ׂ����Q�B�������z�B
class CpuInfo {
public:
	typedef std::vector<std::pair<Point, Point> > PosSpd;

	/// player �̑傫���B
	virtual double getPlayerSize() =0;

	/// player �̈ʒu
	virtual Point getPlayerPnt() =0;

	/// player �̑��x
	virtual double getPlayerSpd() =0;

	/// player �̈ړ��ł���ő���W�l�B
	virtual Point getPlayerMaxPnt() =0;

	/// Bullet �̈ʒu�Ƒ��x����������ŕԂ��B
	virtual void getBulletsPosAndSpd(PosSpd& posspd) =0;

	/// FPS
	virtual double getFps() =0;

	/// ���݂̃^�[����
	virtual int getTurn() =0;

	/// SPF �I�[�o�[���C�h���Ȃ��ėǂ��B
	virtual double getSpf() {
		return 1.0 / getFps();
	}

};

#endif // ! cpuinfo_h_



