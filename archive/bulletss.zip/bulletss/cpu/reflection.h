/**
 * $Id: reflection.h,v 1.1 2003/09/06 22:53:28 i Exp $
 *
 * Copyright (C) shinichiro.h <s31552@mail.ecc.u-tokyo.ac.jp>
 *  http://user.ecc.u-tokyo.ac.jp/~s31552/wp/
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef reflection_h_
#define reflection_h_

#include "cpu.h"

/// ����
/**
 * �e�Ƃ̋����ɔ���Ⴕ�A�e�̑��x�ɔ�Ⴕ�A�e�̎��@�ɑ΂���p�x�ɔ�Ⴗ��A
 * �댯�x���v�Z���āA����ɂ���Ĕ��f���s���B
 */
class ReflectionCpu : public CpuInputBase {
public:
    ReflectionCpu();

private:
	virtual void calc();
    double dangerPoint(Point mypnt, PosSpds& posspd);

};

#endif // ! reflection_h_
